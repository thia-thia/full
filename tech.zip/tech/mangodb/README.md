npm install express mongoose body-parser cors
mongod
node server.js
