import java.lang.management.ManagementFactory;

public class SystemInfo {
    public static void main(String[] args) {
        // Get the operating system name
        String osName = System.getProperty("os.name");

        // Get the total memory in the JVM
        long totalMemory = Runtime.getRuntime().totalMemory(); // in bytes
        double totalMemoryInGB = (double) totalMemory / (1024 * 1024 * 1024);

        // Get the available system memory using OperatingSystemMXBean
        com.sun.management.OperatingSystemMXBean osBean =
            (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
        long systemTotalMemory = osBean.getTotalPhysicalMemorySize(); // in bytes
        double systemTotalMemoryInGB = (double) systemTotalMemory / (1024 * 1024 * 1024);

        // Print the results
        System.out.println("Operating System: " + osName);
        System.out.println("JVM Total Memory: " + String.format("%.2f GB", totalMemoryInGB));
        System.out.println("System Total Memory: " + String.format("%.2f GB", systemTotalMemoryInGB));
    }
}